#include <stdio.h>
#include <stdlib.h> 
#include "inc_a.h"
 
void func_a(void)
{
	printf( "\nHello, I m func_a!\n" );
}
