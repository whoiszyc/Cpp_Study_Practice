#include <stdio.h>
#include <stdlib.h>
#include <tstlib.h> 

void tlib_hello_func_a(void)
{
	printf( "\nHello, I m tlib_hello_func_a from tstlib.a!\n" );
}

