#include <stdio.h>
#include <stdlib.h> 
#include <inc_b.h>
#include <tstlib.h>
 
void func_b(void)
{
	printf( "\nHello, I m func_b!\n" );
	tlib_hello_func_b();
}
