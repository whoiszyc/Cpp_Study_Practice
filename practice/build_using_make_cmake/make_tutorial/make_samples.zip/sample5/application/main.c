#include <stdio.h>
#include <stdlib.h>
#include <inc_a.h>
#include <inc_b.h>
#include <tstlib.h>

int main (int arg, char *argv[])
{
	func_a();
	func_b();
	return 0;
}
