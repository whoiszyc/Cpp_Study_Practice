#ifndef _INC_B_

#define _INC_B_

void func_b(void);

#endif

