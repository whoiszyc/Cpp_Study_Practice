# This is a very simple makefile

app: app.c inc_a.h
	cc -o app app.c

